<?php if(session()->has('flash_notification')): ?>
    <?php if(config('flash.framework') === 'tailwind'): ?>
        <?php echo $__env->make('flash::tailwind.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('flash::bootstrap.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php endif; ?>

<?php if(config('flash.validations.enabled')): ?>
    <?php echo $__env->make(config('flash.validations.view'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\stu_roomdb\vendor\josegus\laravel-flash\src/../resources/views/message.blade.php ENDPATH**/ ?>