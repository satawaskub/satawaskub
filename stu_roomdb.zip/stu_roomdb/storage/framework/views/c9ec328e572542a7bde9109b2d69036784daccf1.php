<?php if(isset($errors) && $errors->any()): ?>
    <?php if(config('flash.framework') === 'tailwind'): ?>
        <?php echo $__env->make('flash::tailwind.validation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('flash::bootstrap.validation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\stu_roomdb\vendor\josegus\laravel-flash\src/../resources/views/validations.blade.php ENDPATH**/ ?>